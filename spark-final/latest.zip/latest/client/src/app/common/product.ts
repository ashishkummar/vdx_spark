import { Unit } from "./unit";

export interface Product{
    type:string,
    units:Array<Unit>
}